"""
HasatAI Backend - FastAPI + MongoDB
Tüm modüller: Auth, Farms, Parcels, Sensors, Tasks, Equipment, Fuel, Energy,
Finance, Living Expenses, Inventory, Alerts, Memberships, Warehouses
"""
import os
import uuid
import hashlib
import secrets
from datetime import datetime, timedelta
from typing import Optional, List, Any
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field
import logging

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("hasatai")

# Config
MONGO_URL = os.getenv("MONGO_URL", "mongodb://hasatai-mongodb:27017")
DB_NAME = os.getenv("DB_NAME", "hasatai_db")
CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*").split(",")

# DB
mongo_client: AsyncIOMotorClient = None
db = None


# ==================== HELPERS ====================
def hash_password(password: str) -> str:
    """Basit SHA256 + salt (production'da bcrypt kullan)"""
    salt = "hasatai_salt_2026"
    return hashlib.sha256((password + salt).encode()).hexdigest()


def gen_id(prefix: str = "") -> str:
    """Kısa benzersiz id"""
    return f"{prefix}{uuid.uuid4().hex[:12]}"


def gen_token() -> str:
    return f"hat_{secrets.token_hex(24)}"


# ==================== AUTH ====================
async def get_current_user(request: Request) -> dict:
    """Bearer token veya cookie'den kullanıcıyı al"""
    token = None
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        token = auth_header[7:]
    if not token:
        token = request.cookies.get("session_token")
    if not token:
        raise HTTPException(401, "Not authenticated")

    session = await db.sessions.find_one({"token": token})
    if not session:
        raise HTTPException(401, "Invalid session")

    user = await db.users.find_one({"id": session["user_id"]}, {"_id": 0, "password": 0})
    if not user:
        raise HTTPException(401, "User not found")
    return user


async def get_user_farms(user_id: str) -> List[dict]:
    """Kullanıcının üye olduğu çiftliklerin listesi"""
    memberships = await db.memberships.find({"userId": user_id}, {"_id": 0}).to_list(100)
    farm_ids = [m["farmId"] for m in memberships]
    farms = await db.farms.find({"id": {"$in": farm_ids}}, {"_id": 0}).to_list(100)
    # her çiftliğe rolü iliştir
    role_map = {m["farmId"]: m["role"] for m in memberships}
    for f in farms:
        f["myRole"] = role_map.get(f["id"], "viewer")
    return farms


async def check_farm_access(user_id: str, farm_id: str) -> str:
    """Kullanıcının bu çiftliğe erişimi var mı? Rolünü döndürür"""
    m = await db.memberships.find_one({"userId": user_id, "farmId": farm_id})
    if not m:
        raise HTTPException(403, "Bu çiftliğe erişiminiz yok")
    return m["role"]


# ==================== APP ====================
@asynccontextmanager
async def lifespan(app: FastAPI):
    global mongo_client, db
    mongo_client = AsyncIOMotorClient(MONGO_URL)
    db = mongo_client[DB_NAME]
    await seed_demo_data()
    logger.info("HasatAI backend started")
    yield
    mongo_client.close()


app = FastAPI(title="HasatAI API", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS if CORS_ORIGINS != ["*"] else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==================== DEMO DATA SEED ====================
async def seed_demo_data():
    """İlk açılışta demo veri yükle"""
    if await db.users.count_documents({}) > 0:
        logger.info("Demo data already exists, skipping seed")
        return

    logger.info("Seeding demo data...")

    # Users
    users = [
        {"id":"u1","name":"Ahmet Yılmaz","email":"ahmet@hasatai.com","password":hash_password("demo1234"),"phone":"+90 555 100 10 01"},
        {"id":"u2","name":"Mehmet Kaya","email":"mehmet@hasatai.com","password":hash_password("demo1234"),"phone":"+90 555 100 20 02"},
        {"id":"u3","name":"Ayşe Demir","email":"ayse@hasatai.com","password":hash_password("demo1234"),"phone":"+90 555 100 30 03"},
        {"id":"u4","name":"Sistem Yönetici","email":"admin@hasatai.com","password":hash_password("demo1234"),"phone":"+90 555 100 40 04"},
        {"id":"u5","name":"Hasan Şahin","email":"hasan@hasatai.com","password":hash_password("demo1234"),"phone":"+90 555 100 50 05"},
    ]
    await db.users.insert_many(users)

    # Farms
    farms = [
        {"id":"f1","name":"Yılmaz Çiftliği","city":"İzmir","district":"Menemen","totalAreaDa":142.5,"lat":38.6177,"lng":27.0673,"ownerId":"u1","established":"2015-04-12"},
        {"id":"f2","name":"Yılmaz Bağ-Bahçe","city":"Manisa","district":"Salihli","totalAreaDa":48.0,"lat":38.4810,"lng":28.1380,"ownerId":"u1","established":"2020-09-01"},
        {"id":"f3","name":"Demir Tarım","city":"Aydın","district":"Söke","totalAreaDa":96.5,"lat":37.7470,"lng":27.4100,"ownerId":"u3","established":"2018-03-20"},
    ]
    await db.farms.insert_many(farms)

    # Memberships
    memberships = [
        {"id":"m1","userId":"u1","farmId":"f1","role":"owner","joinedAt":"2015-04-12"},
        {"id":"m2","userId":"u1","farmId":"f2","role":"owner","joinedAt":"2020-09-01"},
        {"id":"m3","userId":"u2","farmId":"f1","role":"field_staff","joinedAt":"2022-03-15"},
        {"id":"m4","userId":"u2","farmId":"f2","role":"field_staff","joinedAt":"2022-03-15"},
        {"id":"m5","userId":"u3","farmId":"f3","role":"owner","joinedAt":"2018-03-20"},
        {"id":"m6","userId":"u3","farmId":"f1","role":"consultant","joinedAt":"2023-06-10"},
        {"id":"m7","userId":"u3","farmId":"f2","role":"consultant","joinedAt":"2023-06-10"},
        {"id":"m8","userId":"u5","farmId":"f3","role":"field_staff","joinedAt":"2023-01-10"},
        {"id":"m9","userId":"u4","farmId":"f1","role":"admin","joinedAt":"2020-01-01"},
    ]
    await db.memberships.insert_many(memberships)

    # Warehouses
    warehouses = [
        {"id":"w1","farmId":"f1","name":"Menemen Ana Depo","capacity":50,"location":"Çiftlik merkezi","lat":38.6177,"lng":27.0673},
        {"id":"w2","farmId":"f1","name":"Sera Yanı Tohum Deposu","capacity":5,"location":"Sera kompleksi","lat":38.6185,"lng":27.0698},
        {"id":"w3","farmId":"f1","name":"Aliağa Soğuk Hava","capacity":30,"location":"Aliağa ilçe","lat":38.7990,"lng":26.9740},
        {"id":"w4","farmId":"f2","name":"Salihli Merkez Depo","capacity":25,"location":"Çiftlik girişi","lat":38.4810,"lng":28.1380},
        {"id":"w5","farmId":"f2","name":"Salihli Bağ Deposu","capacity":8,"location":"Üzüm bağı yanı","lat":38.4825,"lng":28.1410},
        {"id":"w6","farmId":"f3","name":"Söke Ana Depo","capacity":40,"location":"Çiftlik merkezi","lat":37.7470,"lng":27.4100},
        {"id":"w7","farmId":"f3","name":"Söke Yedek Parça","capacity":5,"location":"Atölye binası","lat":37.7475,"lng":27.4115},
    ]
    await db.warehouses.insert_many(warehouses)

    # Parcels
    parcels = [
        {"id":"p1","farmId":"f1","name":"Domates Tarlası A","crop":"Domates","cropClass":"tomato","variety":"H-2274","areaDa":24.5,"status":"growing","planted":"2026-03-15","harvest":"2026-07-20","moisture":42,"ndvi":0.72,"lat":38.6195,"lng":27.0658,"soilType":"Tınlı"},
        {"id":"p2","farmId":"f1","name":"Buğday Tarlası B","crop":"Buğday","cropClass":"wheat","variety":"Trakya 2002","areaDa":38.0,"status":"growing","planted":"2025-11-20","harvest":"2026-06-15","moisture":28,"ndvi":0.58,"lat":38.6160,"lng":27.0712,"soilType":"Killi"},
        {"id":"p3","farmId":"f1","name":"Zeytin Bahçesi","crop":"Zeytin","cropClass":"olive","variety":"Memecik","areaDa":32.0,"status":"growing","planted":"2018-04-10","harvest":"2026-11-01","moisture":35,"ndvi":0.65,"lat":38.6155,"lng":27.0625,"soilType":"Kireçli"},
        {"id":"p4","farmId":"f1","name":"Salatalık Serası","crop":"Salatalık","cropClass":"cucumber","variety":"Beith Alpha","areaDa":8.0,"status":"growing","planted":"2026-02-01","harvest":"2026-05-10","moisture":56,"ndvi":0.81,"lat":38.6185,"lng":27.0698,"soilType":"Tınlı"},
        {"id":"p5","farmId":"f1","name":"Mısır Tarlası","crop":"Mısır","cropClass":"corn","variety":"Pioneer P31D24","areaDa":28.0,"status":"planning","planted":None,"harvest":None,"moisture":18,"ndvi":0.12,"lat":38.6210,"lng":27.0680,"soilType":"Tınlı"},
        {"id":"p6","farmId":"f1","name":"Üzüm Bağı","crop":"Üzüm","cropClass":"grape","variety":"Sultaniye","areaDa":12.0,"status":"growing","planted":"2020-03-20","harvest":"2026-09-01","moisture":38,"ndvi":0.68,"lat":38.6172,"lng":27.0640,"soilType":"Killi"},
        {"id":"p7","farmId":"f2","name":"Bağ Parsel 1","crop":"Üzüm","cropClass":"grape","variety":"Cabernet","areaDa":18.0,"status":"growing","planted":"2019-04-10","harvest":"2026-09-15","moisture":34,"ndvi":0.71,"lat":38.4810,"lng":28.1380,"soilType":"Kireçli"},
        {"id":"p8","farmId":"f2","name":"Bağ Parsel 2","crop":"Üzüm","cropClass":"grape","variety":"Merlot","areaDa":22.0,"status":"growing","planted":"2019-04-10","harvest":"2026-09-15","moisture":36,"ndvi":0.69,"lat":38.4825,"lng":28.1395,"soilType":"Kireçli"},
        {"id":"p9","farmId":"f2","name":"Sebze Bahçesi","crop":"Biber","cropClass":"pepper","variety":"Charleston","areaDa":8.0,"status":"growing","planted":"2026-03-01","harvest":"2026-07-01","moisture":48,"ndvi":0.74,"lat":38.4815,"lng":28.1410,"soilType":"Tınlı"},
        {"id":"p10","farmId":"f3","name":"Pamuk Tarlası A","crop":"Pamuk","cropClass":"cotton","variety":"Carmen","areaDa":42.0,"status":"growing","planted":"2026-04-05","harvest":"2026-10-15","moisture":32,"ndvi":0.55,"lat":37.7470,"lng":27.4100,"soilType":"Tınlı"},
        {"id":"p11","farmId":"f3","name":"Pamuk Tarlası B","crop":"Pamuk","cropClass":"cotton","variety":"Carmen","areaDa":38.5,"status":"growing","planted":"2026-04-05","harvest":"2026-10-15","moisture":30,"ndvi":0.52,"lat":37.7460,"lng":27.4120,"soilType":"Tınlı"},
        {"id":"p12","farmId":"f3","name":"Mısır","crop":"Mısır","cropClass":"corn","variety":"Pioneer","areaDa":16.0,"status":"growing","planted":"2026-03-25","harvest":"2026-09-10","moisture":38,"ndvi":0.66,"lat":37.7480,"lng":27.4090,"soilType":"Tınlı"},
    ]
    await db.parcels.insert_many(parcels)

    # Sensors
    sensors = [
        {"id":"s1","farmId":"f1","parcelId":"p1","name":"Toprak Nem #1","type":"soil_moisture","unit":"%","value":42,"status":"active","battery":78,"lat":38.6196,"lng":27.0660,"deviceId":"TTN-LSE01-001"},
        {"id":"s2","farmId":"f1","parcelId":"p1","name":"Toprak Sıcaklık #1","type":"soil_temperature","unit":"°C","value":19.4,"status":"active","battery":78,"lat":38.6196,"lng":27.0660,"deviceId":"TTN-LSE01-001"},
        {"id":"s3","farmId":"f1","parcelId":"p2","name":"Toprak Nem #2","type":"soil_moisture","unit":"%","value":28,"status":"active","battery":65,"lat":38.6161,"lng":27.0713,"deviceId":"TTN-LSE01-002"},
        {"id":"s4","farmId":"f1","parcelId":"p2","name":"Toprak pH #2","type":"soil_ph","unit":"pH","value":6.8,"status":"active","battery":65,"lat":38.6161,"lng":27.0713,"deviceId":"TTN-LSE01-002"},
        {"id":"s5","farmId":"f1","parcelId":"p3","name":"Toprak EC #3","type":"soil_ec","unit":"µS/cm","value":1240,"status":"active","battery":82,"lat":38.6156,"lng":27.0626,"deviceId":"TTN-LSE01-003"},
        {"id":"s6","farmId":"f1","parcelId":"p4","name":"Sera Hava Nem","type":"air_humidity","unit":"%","value":72,"status":"active","battery":91,"lat":38.6186,"lng":27.0699,"deviceId":"TTN-AIR-001"},
        {"id":"s7","farmId":"f1","parcelId":"p4","name":"Sera Hava Sıcaklık","type":"air_temperature","unit":"°C","value":24.6,"status":"active","battery":91,"lat":38.6186,"lng":27.0699,"deviceId":"TTN-AIR-001"},
        {"id":"s8","farmId":"f1","parcelId":"p4","name":"Sera Işık","type":"light","unit":"lx","value":18400,"status":"active","battery":91,"lat":38.6186,"lng":27.0699,"deviceId":"TTN-AIR-001"},
        {"id":"s9","farmId":"f1","parcelId":None,"name":"Hava İstasyonu","type":"wind","unit":"km/h","value":12,"status":"active","battery":88,"lat":38.6177,"lng":27.0673,"deviceId":"TTN-WS-001"},
        {"id":"s10","farmId":"f1","parcelId":None,"name":"Yağmur Ölçer","type":"rainfall","unit":"mm","value":0,"status":"active","battery":88,"lat":38.6177,"lng":27.0673,"deviceId":"TTN-WS-001"},
        {"id":"s11","farmId":"f1","parcelId":"p6","name":"Toprak Nem #6","type":"soil_moisture","unit":"%","value":38,"status":"active","battery":14,"lat":38.6173,"lng":27.0641,"deviceId":"TTN-LSE01-006"},
        {"id":"s12","farmId":"f1","parcelId":None,"name":"Su Tankı","type":"tank_level","unit":"%","value":64,"status":"active","battery":76,"lat":38.6180,"lng":27.0650,"deviceId":"TTN-TANK-001"},
        {"id":"s13","farmId":"f1","parcelId":None,"name":"Sulama Basınç","type":"water_pressure","unit":"bar","value":2.4,"status":"active","battery":76,"lat":38.6180,"lng":27.0650,"deviceId":"TTN-PRES-001"},
        {"id":"s14","farmId":"f2","parcelId":"p7","name":"Bağ Toprak Nem","type":"soil_moisture","unit":"%","value":34,"status":"active","battery":84,"lat":38.4810,"lng":28.1380,"deviceId":"TTN-LSE01-007"},
        {"id":"s15","farmId":"f2","parcelId":None,"name":"Salihli Hava","type":"air_temperature","unit":"°C","value":22.1,"status":"active","battery":90,"lat":38.4815,"lng":28.1390,"deviceId":"TTN-AIR-002"},
        {"id":"s16","farmId":"f3","parcelId":"p10","name":"Pamuk Toprak Nem","type":"soil_moisture","unit":"%","value":32,"status":"active","battery":71,"lat":37.7470,"lng":27.4100,"deviceId":"TTN-LSE01-010"},
        {"id":"s17","farmId":"f3","parcelId":None,"name":"Söke Hava","type":"air_humidity","unit":"%","value":58,"status":"active","battery":88,"lat":37.7470,"lng":27.4100,"deviceId":"TTN-AIR-003"},
    ]
    await db.sensors.insert_many(sensors)

    # Weather (her çiftlik için)
    weather_data = [
        {"farmId":"f1","current":{"temp":18,"feels":17,"condition":"Parçalı bulutlu","humidity":64,"wind":12,"rain":0,"icon":"⛅"},"forecast":[{"day":"Bgn","high":21,"low":12,"icon":"⛅","rain":5},{"day":"Per","high":23,"low":13,"icon":"☀️","rain":0},{"day":"Cum","high":19,"low":11,"icon":"🌧️","rain":14},{"day":"Cmt","high":17,"low":10,"icon":"🌧️","rain":22},{"day":"Paz","high":20,"low":11,"icon":"⛅","rain":2},{"day":"Pzt","high":22,"low":13,"icon":"☀️","rain":0},{"day":"Sal","high":24,"low":14,"icon":"☀️","rain":0}]},
        {"farmId":"f2","current":{"temp":21,"feels":20,"condition":"Açık","humidity":55,"wind":8,"rain":0,"icon":"☀️"},"forecast":[{"day":"Bgn","high":24,"low":13,"icon":"☀️","rain":0},{"day":"Per","high":25,"low":14,"icon":"☀️","rain":0},{"day":"Cum","high":21,"low":12,"icon":"⛅","rain":8},{"day":"Cmt","high":19,"low":11,"icon":"🌧️","rain":18},{"day":"Paz","high":22,"low":13,"icon":"⛅","rain":1},{"day":"Pzt","high":24,"low":14,"icon":"☀️","rain":0},{"day":"Sal","high":25,"low":15,"icon":"☀️","rain":0}]},
        {"farmId":"f3","current":{"temp":22,"feels":22,"condition":"Güneşli","humidity":62,"wind":14,"rain":0,"icon":"☀️"},"forecast":[{"day":"Bgn","high":25,"low":14,"icon":"☀️","rain":0},{"day":"Per","high":26,"low":15,"icon":"☀️","rain":0},{"day":"Cum","high":22,"low":13,"icon":"⛅","rain":6},{"day":"Cmt","high":20,"low":12,"icon":"🌧️","rain":12},{"day":"Paz","high":23,"low":13,"icon":"⛅","rain":0},{"day":"Pzt","high":25,"low":15,"icon":"☀️","rain":0},{"day":"Sal","high":27,"low":16,"icon":"☀️","rain":0}]},
    ]
    await db.weather.insert_many(weather_data)

    # Tasks
    tasks = [
        {"id":"t1","farmId":"f1","title":"Domates Tarlası A — Sulama","parcelId":"p1","type":"irrigation","status":"planned","due":"2026-04-29","assignedTo":"u2","priority":"high","createdAt":"2026-04-27"},
        {"id":"t2","farmId":"f1","title":"Buğday Tarlası B — Yabancı ot ilaçlama","parcelId":"p2","type":"pesticide","status":"in_progress","due":"2026-04-29","assignedTo":"u2","priority":"medium","createdAt":"2026-04-26"},
        {"id":"t3","farmId":"f1","title":"Zeytin Bahçesi — Budama kontrolü","parcelId":"p3","type":"pruning","status":"planned","due":"2026-04-30","assignedTo":"u2","priority":"low","createdAt":"2026-04-26"},
        {"id":"t4","farmId":"f1","title":"Sera Salatalık — Hasat","parcelId":"p4","type":"harvest","status":"completed","due":"2026-04-28","assignedTo":"u2","priority":"high","completedAt":"2026-04-28","createdAt":"2026-04-25"},
        {"id":"t5","farmId":"f1","title":"Mısır Tarlası — Toprak hazırlığı","parcelId":"p5","type":"planting","status":"planned","due":"2026-05-05","assignedTo":"u2","priority":"medium","createdAt":"2026-04-27"},
        {"id":"t6","farmId":"f1","title":"Üzüm Bağı — Gübreleme","parcelId":"p6","type":"fertilize","status":"overdue","due":"2026-04-26","assignedTo":"u2","priority":"high","createdAt":"2026-04-22"},
        {"id":"t7","farmId":"f1","title":"Sensör #11 — Pil değişimi","parcelId":"p6","type":"maintenance","status":"planned","due":"2026-04-30","assignedTo":"u2","priority":"medium","createdAt":"2026-04-28"},
        {"id":"t8","farmId":"f2","title":"Bağ Parsel 1 — Sulama","parcelId":"p7","type":"irrigation","status":"planned","due":"2026-04-30","assignedTo":"u2","priority":"medium","createdAt":"2026-04-27"},
        {"id":"t9","farmId":"f3","title":"Pamuk A — İlk gübre","parcelId":"p10","type":"fertilize","status":"planned","due":"2026-05-02","assignedTo":"u5","priority":"medium","createdAt":"2026-04-26"},
    ]
    await db.tasks.insert_many(tasks)

    # Expenses
    expenses = [
        {"id":"e1","farmId":"f1","parcelId":"p1","category":"Tohum","amount":8400,"date":"2026-03-10","desc":"Domates fidesi (1500 adet)"},
        {"id":"e2","farmId":"f1","parcelId":"p1","category":"Gübre","amount":3200,"date":"2026-03-20","desc":"NPK 15-15-15"},
        {"id":"e3","farmId":"f1","parcelId":"p1","category":"İşçilik","amount":4800,"date":"2026-03-15","desc":"Dikim işçiliği"},
        {"id":"e4","farmId":"f1","parcelId":"p2","category":"Tohum","amount":12500,"date":"2025-11-15","desc":"Buğday tohumu"},
        {"id":"e5","farmId":"f1","parcelId":"p2","category":"Mazot","amount":6800,"date":"2025-11-20","desc":"Sürüm + ekim"},
        {"id":"e6","farmId":"f1","parcelId":"p2","category":"İlaç","amount":2400,"date":"2026-02-10","desc":"Yabancı ot ilacı"},
        {"id":"e7","farmId":"f1","parcelId":"p3","category":"Bakım","amount":5200,"date":"2026-02-20","desc":"Budama"},
        {"id":"e8","farmId":"f1","parcelId":"p4","category":"Sulama","amount":1800,"date":"2026-04-15","desc":"Damla sulama hattı"},
        {"id":"e9","farmId":"f1","parcelId":"p6","category":"Gübre","amount":2100,"date":"2026-04-05","desc":"Organik gübre"},
        {"id":"e10","farmId":"f1","parcelId":"p6","category":"İşçilik","amount":3600,"date":"2026-04-12","desc":"Asma bağlama"},
        {"id":"e11","farmId":"f2","parcelId":"p7","category":"Bakım","amount":6500,"date":"2026-03-22","desc":"Bağ telleri yenileme"},
        {"id":"e12","farmId":"f2","parcelId":"p9","category":"Tohum","amount":1800,"date":"2026-02-28","desc":"Biber fidesi"},
        {"id":"e13","farmId":"f3","parcelId":"p10","category":"Tohum","amount":18000,"date":"2026-04-01","desc":"Pamuk tohumu"},
        {"id":"e14","farmId":"f3","parcelId":"p10","category":"Mazot","amount":9200,"date":"2026-04-05","desc":"Toprak hazırlığı + ekim"},
    ]
    await db.expenses.insert_many(expenses)

    # Revenues
    revenues = [
        {"id":"r1","farmId":"f1","parcelId":"p4","product":"Salatalık","quantity":4200,"unitPrice":18,"total":75600,"date":"2026-04-28","buyer":"Migros"},
        {"id":"r2","farmId":"f1","parcelId":"p3","product":"Zeytin (geçen sezon)","quantity":2800,"unitPrice":32,"total":89600,"date":"2025-11-15","buyer":"Tariş"},
        {"id":"r3","farmId":"f1","parcelId":"p6","product":"Üzüm (geçen sezon)","quantity":1500,"unitPrice":28,"total":42000,"date":"2025-09-20","buyer":"Yerel pazar"},
        {"id":"r4","farmId":"f2","parcelId":"p7","product":"Üzüm (geçen sezon)","quantity":8400,"unitPrice":35,"total":294000,"date":"2025-09-25","buyer":"Kavaklıdere Şarap"},
        {"id":"r5","farmId":"f3","parcelId":"p10","product":"Pamuk (geçen sezon)","quantity":5200,"unitPrice":42,"total":218400,"date":"2025-10-30","buyer":"Söke Çırçır"},
    ]
    await db.revenues.insert_many(revenues)

    # Inventory
    inventory = [
        {"id":"i1","farmId":"f1","warehouseId":"w1","name":"NPK 15-15-15 Gübre","category":"Gübre","stock":240,"min":100,"unit":"kg","cost":32,"supplier":"Toros Tarım"},
        {"id":"i2","farmId":"f1","warehouseId":"w2","name":"Domates Tohumu H-2274","category":"Tohum","stock":8,"min":5,"unit":"paket","cost":850,"supplier":"Multi-Tohum"},
        {"id":"i3","farmId":"f1","warehouseId":"w1","name":"Buğday Tohumu Trakya","category":"Tohum","stock":320,"min":200,"unit":"kg","cost":18,"supplier":"TİGEM"},
        {"id":"i4","farmId":"f1","warehouseId":"w1","name":"Yabancı Ot İlacı","category":"İlaç","stock":4,"min":6,"unit":"lt","cost":280,"supplier":"Bayer"},
        {"id":"i5","farmId":"f1","warehouseId":"w1","name":"Mantar İlacı","category":"İlaç","stock":12,"min":5,"unit":"lt","cost":320,"supplier":"Syngenta"},
        {"id":"i6","farmId":"f1","warehouseId":"w1","name":"Mazot","category":"Yakıt","stock":180,"min":200,"unit":"lt","cost":42,"supplier":"Petrol Ofisi"},
        {"id":"i7","farmId":"f1","warehouseId":"w1","name":"Damla Sulama Borusu","category":"Ekipman","stock":1200,"min":300,"unit":"metre","cost":4,"supplier":"Aksa Plastik"},
        {"id":"i8","farmId":"f1","warehouseId":"w3","name":"Domates (depoda)","category":"Ürün","stock":680,"min":0,"unit":"kg","cost":0,"supplier":"Hasat"},
        {"id":"i9","farmId":"f2","warehouseId":"w4","name":"Bordo Bulamacı","category":"İlaç","stock":18,"min":8,"unit":"kg","cost":48,"supplier":"Hektaş"},
        {"id":"i10","farmId":"f2","warehouseId":"w5","name":"Üzüm Filesi","category":"Ekipman","stock":240,"min":100,"unit":"metre","cost":6,"supplier":"Aksa Plastik"},
        {"id":"i11","farmId":"f3","warehouseId":"w6","name":"Pamuk Tohumu","category":"Tohum","stock":65,"min":30,"unit":"kg","cost":380,"supplier":"May Tohumculuk"},
        {"id":"i12","farmId":"f3","warehouseId":"w7","name":"Lastik (traktör)","category":"Yedek Parça","stock":2,"min":1,"unit":"adet","cost":8500,"supplier":"Petlas"},
    ]
    await db.inventory.insert_many(inventory)

    # Alerts
    alerts = [
        {"id":"a1","farmId":"f1","type":"frost","severity":"danger","title":"Don Riski — Cumartesi gecesi","parcelId":"p1","message":"Cumartesi gecesi sıcaklığın +1°C'ye düşmesi bekleniyor.","time":"2 saat önce","isRead":False},
        {"id":"a2","farmId":"f1","type":"low_moisture","severity":"warn","title":"Düşük Toprak Nemi","parcelId":"p2","message":"Buğday Tarlası B nemi %28'e düştü.","time":"4 saat önce","isRead":False},
        {"id":"a3","farmId":"f1","type":"low_battery","severity":"warn","title":"Sensör Pili Kritik","parcelId":"p6","message":"Üzüm Bağı sensörü pili %14.","time":"6 saat önce","isRead":False},
        {"id":"a4","farmId":"f1","type":"wind","severity":"info","title":"Kuvvetli Rüzgar Bekleniyor","message":"Yarın rüzgar 35 km/h'a ulaşabilir.","time":"8 saat önce","isRead":False},
        {"id":"a5","farmId":"f1","type":"low_stock","severity":"warn","title":"Kritik Stok: Yabancı Ot İlacı","message":"Stok 4 lt'ye düştü.","time":"1 gün önce","isRead":True},
        {"id":"a6","farmId":"f1","type":"rain","severity":"info","title":"Yağmur Bekleniyor","message":"Cuma-Cumartesi 36mm yağış bekleniyor.","time":"1 gün önce","isRead":False},
        {"id":"a7","farmId":"f1","type":"overdue_task","severity":"danger","title":"Geciken Görev","parcelId":"p6","message":"Üzüm Bağı gübreleme görevi 3 gün gecikti.","time":"2 gün önce","isRead":False},
        {"id":"a8","farmId":"f2","type":"low_stock","severity":"warn","title":"Salihli — Bordo Bulamacı stoku","message":"Stok azalıyor.","time":"5 saat önce","isRead":False},
        {"id":"a9","farmId":"f3","type":"low_moisture","severity":"info","title":"Pamuk B — Nem takibi","parcelId":"p11","message":"Nem %30, yakın takipte tutulmalı.","time":"12 saat önce","isRead":True},
    ]
    await db.alerts.insert_many(alerts)

    # Equipment
    equipment = [
        {"id":"eq1","farmId":"f1","name":"John Deere 6120M","type":"tractor","model":"6120M","year":2022,"plate":"35 ABC 123","status":"active","operator":"u2","fuelLevel":68,"hoursWorked":1248,"lastMaintenance":"2026-03-20","nextMaintenance":"2026-06-20","tracker":"Teltonika FMB920","lat":38.6195,"lng":27.0658,"currentTask":"Domates tarlası — sürüm","purchasePrice":2400000},
        {"id":"eq2","farmId":"f1","name":"Pulluk 5'li","type":"plough","model":"Aksoy P5","year":2018,"plate":"","status":"idle","operator":None,"fuelLevel":None,"hoursWorked":520,"lastMaintenance":"2026-02-10","nextMaintenance":"2026-08-10","tracker":"AirTag","lat":38.6177,"lng":27.0673,"currentTask":None,"purchasePrice":180000},
        {"id":"eq3","farmId":"f1","name":"Mibzer (ekim makinesi)","type":"planter","model":"Solà SPV-7","year":2020,"plate":"","status":"maintenance","operator":None,"fuelLevel":None,"hoursWorked":340,"lastMaintenance":"2026-04-25","nextMaintenance":"2026-10-25","tracker":"AirTag","lat":38.6177,"lng":27.0673,"currentTask":None,"purchasePrice":420000},
        {"id":"eq4","farmId":"f1","name":"Sulama Pompası 1","type":"pump","model":"Pedrollo 4HP","year":2021,"plate":"","status":"active","operator":None,"fuelLevel":None,"hoursWorked":2400,"lastMaintenance":"2026-01-15","nextMaintenance":"2026-07-15","tracker":"Shelly Pro 2PM","lat":38.6180,"lng":27.0650,"currentTask":"Sera sulama","purchasePrice":24000},
        {"id":"eq5","farmId":"f1","name":"Çapa Makinesi","type":"tiller","model":"BCS 740","year":2019,"plate":"","status":"idle","operator":None,"fuelLevel":32,"hoursWorked":680,"lastMaintenance":"2026-03-01","nextMaintenance":"2026-09-01","tracker":"AirTag","lat":38.6177,"lng":27.0673,"currentTask":None,"purchasePrice":85000},
        {"id":"eq6","farmId":"f2","name":"New Holland T4","type":"tractor","model":"T4.55","year":2020,"plate":"45 DEF 456","status":"active","operator":"u2","fuelLevel":42,"hoursWorked":980,"lastMaintenance":"2026-04-01","nextMaintenance":"2026-10-01","tracker":"Teltonika FMB920","lat":38.4810,"lng":28.1380,"currentTask":"Bağ ilaçlama","purchasePrice":1800000},
        {"id":"eq7","farmId":"f3","name":"Massey Ferguson 4708","type":"tractor","model":"4708","year":2023,"plate":"09 XYZ 789","status":"active","operator":"u5","fuelLevel":84,"hoursWorked":420,"lastMaintenance":"2026-02-15","nextMaintenance":"2026-08-15","tracker":"Teltonika FMB920","lat":37.7470,"lng":27.4100,"currentTask":"Pamuk tarlası — gübre uygulama","purchasePrice":2200000},
        {"id":"eq8","farmId":"f3","name":"Pamuk Hasat Makinesi","type":"harvester","model":"JD CP690","year":2021,"plate":"","status":"idle","operator":None,"fuelLevel":None,"hoursWorked":180,"lastMaintenance":"2025-11-20","nextMaintenance":"2026-09-15","tracker":"GPS","lat":37.7470,"lng":27.4100,"currentTask":None,"purchasePrice":8500000},
    ]
    await db.equipment.insert_many(equipment)

    # Fuel logs
    fuel_logs = [
        {"id":"fl1","farmId":"f1","equipmentId":"eq1","date":"2026-04-28","type":"fill","liters":120,"cost":5040,"pricePerL":42,"station":"Çiftlik tankı","odometer":1248,"notes":"Hafta sonu için"},
        {"id":"fl2","farmId":"f1","equipmentId":"eq1","date":"2026-04-22","type":"fill","liters":100,"cost":4150,"pricePerL":41.5,"station":"Petrol Ofisi","odometer":1180,"notes":""},
        {"id":"fl3","farmId":"f1","equipmentId":"eq1","date":"2026-04-15","type":"usage","liters":45,"cost":1890,"pricePerL":42,"station":"-","odometer":1135,"notes":"Domates tarlası sürüm"},
        {"id":"fl4","farmId":"f1","equipmentId":"eq5","date":"2026-04-20","type":"fill","liters":30,"cost":1260,"pricePerL":42,"station":"Çiftlik tankı","odometer":680,"notes":""},
        {"id":"fl5","farmId":"f2","equipmentId":"eq6","date":"2026-04-26","type":"fill","liters":80,"cost":3360,"pricePerL":42,"station":"Salihli BP","odometer":980,"notes":""},
        {"id":"fl6","farmId":"f3","equipmentId":"eq7","date":"2026-04-27","type":"fill","liters":140,"cost":5880,"pricePerL":42,"station":"Söke Shell","odometer":420,"notes":"Hasat öncesi"},
    ]
    await db.fuelLogs.insert_many(fuel_logs)

    # Fuel tanks
    fuel_tanks = [
        {"id":"ft1","farmId":"f1","name":"Ana Tank","capacity":2000,"currentLevel":1240,"type":"mazot","sensorId":None,"lastFilled":"2026-04-15","lat":38.6177,"lng":27.0673},
        {"id":"ft2","farmId":"f1","name":"Sera Mini Tank","capacity":200,"currentLevel":65,"type":"mazot","sensorId":None,"lastFilled":"2026-04-20","lat":38.6185,"lng":27.0698},
        {"id":"ft3","farmId":"f2","name":"Salihli Tank","capacity":1000,"currentLevel":540,"type":"mazot","sensorId":None,"lastFilled":"2026-04-18","lat":38.4810,"lng":28.1380},
        {"id":"ft4","farmId":"f3","name":"Söke Ana Tank","capacity":3000,"currentLevel":2100,"type":"mazot","sensorId":None,"lastFilled":"2026-04-22","lat":37.7470,"lng":27.4100},
    ]
    await db.fuelTanks.insert_many(fuel_tanks)

    # Energy systems
    energy = [
        {"id":"en1","farmId":"f1","name":"Çatı GES (Çiftlik Evi)","type":"solar","capacityKw":25,"installedAt":"2024-06-15","currentProduction":18.4,"todayKwh":124,"monthKwh":3640,"totalKwh":42800,"savings":182000,"panels":50},
        {"id":"en2","farmId":"f1","name":"Sera GES","type":"solar","capacityKw":50,"installedAt":"2024-08-20","currentProduction":38.2,"todayKwh":248,"monthKwh":7200,"totalKwh":84000,"savings":358000,"panels":100},
        {"id":"en3","farmId":"f1","name":"Sulama GES (Pompa)","type":"solar","capacityKw":8,"installedAt":"2025-03-10","currentProduction":6.1,"todayKwh":42,"monthKwh":1180,"totalKwh":9800,"savings":42000,"panels":16},
        {"id":"en4","farmId":"f2","name":"Bağ GES","type":"solar","capacityKw":15,"installedAt":"2025-01-15","currentProduction":11.2,"todayKwh":78,"monthKwh":2200,"totalKwh":18400,"savings":78000,"panels":30},
        {"id":"en5","farmId":"f3","name":"Söke Mega GES","type":"solar","capacityKw":80,"installedAt":"2024-11-01","currentProduction":62.5,"todayKwh":420,"monthKwh":11800,"totalKwh":124000,"savings":528000,"panels":160},
        {"id":"en6","farmId":"f3","name":"Rüzgar Türbini Pilot","type":"wind","capacityKw":5,"installedAt":"2025-09-20","currentProduction":2.4,"todayKwh":18,"monthKwh":480,"totalKwh":1200,"savings":5100,"panels":1},
    ]
    await db.energySystems.insert_many(energy)

    # Living expenses
    living = [
        {"id":"lv1","farmId":"f1","category":"Elektrik (ev)","amount":1840,"date":"2026-04-15","period":"2026-03","desc":"Çiftlik konutu elektrik faturası","meter":"EL-001"},
        {"id":"lv2","farmId":"f1","category":"Su (kuyu+şebeke)","amount":680,"date":"2026-04-15","period":"2026-03","desc":"Konut + iş yeri su tüketimi","meter":"SU-001"},
        {"id":"lv3","farmId":"f1","category":"Doğalgaz","amount":2200,"date":"2026-04-15","period":"2026-03","desc":"Konut ısıtma + ocak","meter":"GAZ-001"},
        {"id":"lv4","farmId":"f1","category":"Mutfak/Yemek","amount":8500,"date":"2026-04-30","period":"2026-04","desc":"Aylık mutfak harcaması","meter":"-"},
        {"id":"lv5","farmId":"f1","category":"İnternet/Telefon","amount":480,"date":"2026-04-10","period":"2026-04","desc":"Türk Telekom + GSM","meter":"-"},
        {"id":"lv6","farmId":"f1","category":"Konut Bakım","amount":1200,"date":"2026-04-20","period":"2026-04","desc":"Çatı tamiri","meter":"-"},
        {"id":"lv7","farmId":"f1","category":"Su Motoru Elektrik","amount":3400,"date":"2026-04-15","period":"2026-03","desc":"Sulama motoru elektriği","meter":"EL-002"},
        {"id":"lv8","farmId":"f2","category":"Elektrik (ev)","amount":1240,"date":"2026-04-12","period":"2026-03","desc":"Salihli konut","meter":"EL-101"},
        {"id":"lv9","farmId":"f2","category":"Su","amount":380,"date":"2026-04-12","period":"2026-03","desc":"","meter":"SU-101"},
        {"id":"lv10","farmId":"f3","category":"Elektrik","amount":2100,"date":"2026-04-15","period":"2026-03","desc":"Söke çiftlik konutu","meter":"EL-201"},
    ]
    await db.livingExpenses.insert_many(living)

    logger.info(f"✓ Seed complete: {len(users)} users, {len(farms)} farms, {len(parcels)} parcels")


# ==================== ROUTES ====================
@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "hasatai", "version": "1.0"}


# ---- Auth ----
class LoginIn(BaseModel):
    email: str
    password: str


@app.post("/api/auth/login")
async def login(payload: LoginIn):
    user = await db.users.find_one({"email": payload.email.lower()})
    if not user or user["password"] != hash_password(payload.password):
        raise HTTPException(401, "E-posta veya şifre hatalı")

    token = gen_token()
    await db.sessions.insert_one({
        "token": token,
        "user_id": user["id"],
        "createdAt": datetime.utcnow().isoformat()
    })

    user_safe = {k: v for k, v in user.items() if k not in ("password", "_id")}
    return {"user": user_safe, "session_token": token}


@app.post("/api/auth/logout")
async def logout(user: dict = Depends(get_current_user), request: Request = None):
    token = request.headers.get("Authorization", "").replace("Bearer ", "") or request.cookies.get("session_token")
    if token:
        await db.sessions.delete_one({"token": token})
    return {"ok": True}


@app.get("/api/auth/me")
async def me(user: dict = Depends(get_current_user)):
    farms = await get_user_farms(user["id"])
    return {"user": user, "farms": farms}


# ---- Generic CRUD generator ----
def make_crud(collection_name: str, prefix: str, item_id_prefix: str = ""):
    """Belirli bir koleksiyon için CRUD endpoint'leri ekler"""

    @app.get(f"/api/{prefix}")
    async def list_items(farmId: Optional[str] = None, user: dict = Depends(get_current_user)):
        query = {}
        if farmId:
            await check_farm_access(user["id"], farmId)
            query["farmId"] = farmId
        else:
            # Sadece üye olduğu çiftlikler
            farms = await get_user_farms(user["id"])
            query["farmId"] = {"$in": [f["id"] for f in farms]}
        items = await db[collection_name].find(query, {"_id": 0}).to_list(1000)
        return items

    @app.post(f"/api/{prefix}")
    async def create_item(payload: dict, user: dict = Depends(get_current_user)):
        if "farmId" in payload:
            await check_farm_access(user["id"], payload["farmId"])
        if "id" not in payload:
            payload["id"] = gen_id(item_id_prefix)
        await db[collection_name].insert_one(payload.copy())
        result = await db[collection_name].find_one({"id": payload["id"]}, {"_id": 0})
        return result

    @app.put(f"/api/{prefix}/{{item_id}}")
    async def update_item(item_id: str, payload: dict, user: dict = Depends(get_current_user)):
        existing = await db[collection_name].find_one({"id": item_id})
        if not existing:
            raise HTTPException(404, "Not found")
        if "farmId" in existing:
            await check_farm_access(user["id"], existing["farmId"])
        payload.pop("_id", None)
        payload["id"] = item_id
        await db[collection_name].replace_one({"id": item_id}, payload)
        return await db[collection_name].find_one({"id": item_id}, {"_id": 0})

    @app.delete(f"/api/{prefix}/{{item_id}}")
    async def delete_item(item_id: str, user: dict = Depends(get_current_user)):
        existing = await db[collection_name].find_one({"id": item_id})
        if not existing:
            raise HTTPException(404, "Not found")
        if "farmId" in existing:
            await check_farm_access(user["id"], existing["farmId"])
        await db[collection_name].delete_one({"id": item_id})
        return {"ok": True}


# Tüm modüller için CRUD üret
make_crud("parcels", "parcels", "p")
make_crud("sensors", "sensors", "s")
make_crud("tasks", "tasks", "t")
make_crud("expenses", "expenses", "e")
make_crud("revenues", "revenues", "r")
make_crud("inventory", "inventory", "i")
make_crud("alerts", "alerts", "a")
make_crud("equipment", "equipment", "eq")
make_crud("fuelLogs", "fuel-logs", "fl")
make_crud("fuelTanks", "fuel-tanks", "ft")
make_crud("energySystems", "energy", "en")
make_crud("livingExpenses", "living-expenses", "lv")
make_crud("warehouses", "warehouses", "w")


# ---- Farms (özel) ----
@app.get("/api/farms")
async def list_farms(user: dict = Depends(get_current_user)):
    return await get_user_farms(user["id"])


@app.get("/api/farms/{farm_id}")
async def get_farm(farm_id: str, user: dict = Depends(get_current_user)):
    await check_farm_access(user["id"], farm_id)
    farm = await db.farms.find_one({"id": farm_id}, {"_id": 0})
    if not farm:
        raise HTTPException(404, "Farm not found")
    return farm


# ---- Memberships (özel) ----
@app.get("/api/memberships")
async def list_memberships(farmId: Optional[str] = None, user: dict = Depends(get_current_user)):
    if farmId:
        await check_farm_access(user["id"], farmId)
        memberships = await db.memberships.find({"farmId": farmId}, {"_id": 0}).to_list(1000)
    else:
        farms = await get_user_farms(user["id"])
        farm_ids = [f["id"] for f in farms]
        memberships = await db.memberships.find({"farmId": {"$in": farm_ids}}, {"_id": 0}).to_list(1000)

    # Her membership'e user bilgisini ekle
    user_ids = list(set(m["userId"] for m in memberships))
    users = await db.users.find({"id": {"$in": user_ids}}, {"_id": 0, "password": 0}).to_list(1000)
    user_map = {u["id"]: u for u in users}
    for m in memberships:
        m["user"] = user_map.get(m["userId"])
    return memberships


# ---- Users (sadece okuma için) ----
@app.get("/api/users")
async def list_users(user: dict = Depends(get_current_user)):
    users = await db.users.find({}, {"_id": 0, "password": 0}).to_list(1000)
    return users


# ---- Weather (özel - read-only) ----
@app.get("/api/weather/{farm_id}")
async def get_weather(farm_id: str, user: dict = Depends(get_current_user)):
    await check_farm_access(user["id"], farm_id)
    w = await db.weather.find_one({"farmId": farm_id}, {"_id": 0})
    if not w:
        raise HTTPException(404, "Weather not found")
    return w


# ---- Alerts read mark ----
@app.post("/api/alerts/{alert_id}/read")
async def mark_alert_read(alert_id: str, user: dict = Depends(get_current_user)):
    alert = await db.alerts.find_one({"id": alert_id})
    if not alert:
        raise HTTPException(404, "Alert not found")
    await check_farm_access(user["id"], alert["farmId"])
    await db.alerts.update_one({"id": alert_id}, {"$set": {"isRead": True}})
    return {"ok": True}


# ---- Reset/Reseed (admin only - dev için) ----
@app.post("/api/admin/reseed")
async def reseed():
    """Tüm veriyi siler, demo'yu yeniden yükler. Production'da kapatılmalı!"""
    collections = ["users", "farms", "memberships", "warehouses", "parcels", "sensors",
                   "weather", "tasks", "expenses", "revenues", "inventory", "alerts",
                   "equipment", "fuelLogs", "fuelTanks", "energySystems", "livingExpenses", "sessions"]
    for c in collections:
        await db[c].delete_many({})
    await seed_demo_data()
    return {"ok": True, "message": "Demo data reseeded"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
