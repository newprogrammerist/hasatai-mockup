# 🌾 HasatAI - Kurulum Rehberi

Akıllı tarım yönetim platformu. FastAPI + MongoDB + Premium HTML Frontend.

## 📦 Stack

- **Backend:** FastAPI (Python 3.11) + Motor (async MongoDB)
- **Database:** MongoDB 7
- **Frontend:** Premium HTML + Vanilla JS + Chart.js + Leaflet
- **Deployment:** Docker Compose
- **Port:** 8080

## 🚀 Kurulum (Sunucuda)

### Adım 1 — Klasörü hazırla
```bash
mkdir -p /opt/hasatai && cd /opt/hasatai
```

### Adım 2 — Tar.gz'yi sunucuya yükle
GitHub'a `hasatai.tar.gz` olarak yükledikten sonra:

```bash
cd /opt/hasatai
git clone https://github.com/KULLANICIN/hasatai.git .
# veya
wget https://github.com/KULLANICIN/hasatai/raw/main/hasatai.tar.gz
tar -xzf hasatai.tar.gz
```

### Adım 3 — Çalıştır
```bash
docker compose up -d --build
```

5-10 dakika sürer (build).

### Adım 4 — Test
Tarayıcıda aç: **http://SUNUCU_IP:8080**

## 👤 Demo Kullanıcılar

| E-posta | Şifre | Rol |
|---------|-------|-----|
| ahmet@hasatai.com | demo1234 | Çiftlik Sahibi (2 çiftlik) |
| ayse@hasatai.com | demo1234 | Danışman (3 çiftlik) |
| mehmet@hasatai.com | demo1234 | Saha Personeli |
| admin@hasatai.com | demo1234 | Sistem Yönetici |

Login ekranındaki rozetlere tıklayarak hızlı giriş yapılabilir.

## 🏗️ Yapı

```
hasatai/
├── backend/
│   ├── server.py            # FastAPI + tüm modüller + demo seed
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── index.html           # Premium HTML mockup → API'ye bağlı
│   ├── nginx.conf           # API proxy + SPA serve
│   └── Dockerfile
└── docker-compose.yml       # 3 servis: mongodb + backend + frontend
```

## 🔌 API Endpoints

Tüm endpoint'ler `/api/` prefix'i ile çalışır.

### Auth
- `POST /api/auth/login` — Email + şifre → token
- `POST /api/auth/logout` — Çıkış
- `GET  /api/auth/me` — Mevcut kullanıcı + çiftlikler

### CRUD Modülleri (her biri için GET, POST, PUT, DELETE)
- `/api/farms`
- `/api/parcels` — Tarla & Parsel
- `/api/sensors` — Sensörler
- `/api/tasks` — Görevler
- `/api/expenses` — Giderler
- `/api/revenues` — Gelirler
- `/api/inventory` — Envanter
- `/api/alerts` — Uyarılar
- `/api/equipment` — Ekipman & GPS
- `/api/fuel-logs` — Yakıt kayıtları
- `/api/fuel-tanks` — Yakıt tankları
- `/api/energy` — Yenilenebilir enerji
- `/api/living-expenses` — Yaşam giderleri
- `/api/warehouses` — Depolar
- `/api/memberships` — Üyelikler

### Özel
- `GET  /api/weather/{farmId}` — Hava durumu
- `POST /api/alerts/{id}/read` — Uyarıyı okundu işaretle
- `POST /api/admin/reseed` — Demo veriyi sıfırla (dev only)

## 🔄 Güncelleme

```bash
cd /opt/hasatai
git pull
docker compose up -d --build
```

## 🗑️ Veriyi Sıfırlama

```bash
# Tüm DB'yi sil + demo'yu yeniden yükle
curl -X POST http://localhost:8080/api/admin/reseed
```

veya:

```bash
docker compose down -v   # volume da sil
docker compose up -d --build
```

## 📊 Modüller

✅ **Mevcut MVP:**
- 🏠 Dashboard (özet)
- 🌾 Tarla & Parsel + Harita
- 📡 Sensörler (13 tip, mock canlı veri)
- 🌤️ Hava & Uydu (7 günlük tahmin)
- 💧 Sulama Önerileri (kural motoru)
- ✅ Görevler (atama, durum)
- 🚜 Ekipman & GPS (canlı harita)
- ⛽ Yakıt Takibi (tank seviye)
- ☀️ Yenilenebilir Enerji
- 💰 Maliyet & Gelir
- 🏠 Yaşam Giderleri
- 📦 Envanter (multi-warehouse)
- 👥 Ekip & Üyelik (multi-tenant RBAC)
- 🔔 Uyarılar
- 📊 Raporlar (özelleştirilebilir)

🔜 **Sonra eklenecek:**
- 🐄 Hayvancılık (sürü, süt, yumurta, sağlık, yem)
- 🏗️ Yapılar (sera, ahır, kümes, depo)
- 📈 Borsa & Piyasa
- 🤖 AI Asistan
- 📱 Mobile App
